
import pandas as pd
import matplotlib.pyplot as plt

def analyze_traffic(filename="urlcc_synthetic.csv"):
    df = pd.read_csv(filename)

    avg_latency = df["latency_ms"].mean()
    packet_loss_rate = df["packet_loss"].mean() * 100

    print(f"Average Latency: {avg_latency:.3f} ms")
    print(f"Packet Loss Rate: {packet_loss_rate:.3f} %")

    # Plot latency
    plt.figure(figsize=(10, 5))
    plt.plot(df["timestamp_ms"], df["latency_ms"], label="Latency (ms)", color="blue")
    plt.title("URLLC Traffic Latency Over Time")
    plt.xlabel("Time (ms)")
    plt.ylabel("Latency (ms)")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig("latency_plot.png")
    plt.show()

    # Plot packet loss
    plt.figure(figsize=(10, 3))
    plt.plot(df["timestamp_ms"], df["packet_loss"], label="Packet Loss", color="red")
    plt.title("URLLC Packet Loss Over Time")
    plt.xlabel("Time (ms)")
    plt.ylabel("Loss (0 or 1)")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("packet_loss_plot.png")
    plt.show()

if __name__ == "__main__":
    analyze_traffic()
