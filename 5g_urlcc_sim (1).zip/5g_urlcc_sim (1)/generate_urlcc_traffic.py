
import numpy as np
import pandas as pd

def generate_urlcc_traffic(filename="urlcc_synthetic.csv", n_packets=1000):
    data = {
        "timestamp_ms": np.arange(0, n_packets),
        "latency_ms": np.random.normal(loc=1, scale=0.1, size=n_packets),  # ~1ms latency
        "packet_loss": np.random.choice([0, 1], size=n_packets, p=[0.999, 0.001]),  # 0.1% loss
    }
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)
    print(f"Saved synthetic URLLC traffic to {filename}")

if __name__ == "__main__":
    generate_urlcc_traffic()
