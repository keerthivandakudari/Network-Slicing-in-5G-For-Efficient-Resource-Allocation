# 5G mMTC Network Slicing with Visualization

## Requirements
- Python 3.x
- pandas
- matplotlib

## How to Run
1. Install required libraries:
   pip install pandas matplotlib

2. Run the script:
   python slicing_simulation.py

3. Output:
- Displays bar charts
- Saves graphs as PNG images