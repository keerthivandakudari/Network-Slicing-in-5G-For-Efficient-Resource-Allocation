import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("iot_devices_200.csv")

# Define slices
agriculture_slice = df[df['Location'].str.contains("Farm")]
urban_slice = df[df['Location'].str.contains("SmartCity")]

# Slice counts
slice_counts = {
    'Agriculture': len(agriculture_slice),
    
    'Urban': len(urban_slice)
}

# Average power consumption
avg_power = {
    'Agriculture': agriculture_slice['Power Consumption (mW)'].mean(),
    'Urban': urban_slice['Power Consumption (mW)'].mean()
}

# Plot: Number of Devices per Slice
plt.figure(figsize=(6, 4))
plt.bar(slice_counts.keys(), slice_counts.values(), color=['green', 'blue'])
plt.title("Number of Devices per mMTC Slice")
plt.ylabel("Number of Devices")
plt.grid(axis='y')
plt.tight_layout()
plt.savefig("devices_per_slice.png")
plt.show()

# Plot: Average Power Consumption per Slice
plt.figure(figsize=(6, 4))
plt.bar(avg_power.keys(), avg_power.values(), color=['green', 'blue'])
plt.title("Average Power Consumption per Slice")
plt.ylabel("Power Consumption (mW)")
plt.grid(axis='y')
plt.tight_layout()
plt.savefig("avg_power_consumption.png")
plt.show()

# Print slices
print("=== Agriculture Slice ===")
print(agriculture_slice)
print("\n=== Urban Slice ===")
print(urban_slice)